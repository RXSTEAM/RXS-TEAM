<?php
session_start();
require "config.php";

// Redirect to login page if not logged in
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header("Location: login.php");
    exit();
}

$errorMessage = "";
$successMessage = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['generate_key'])) {
        $key = empty($_POST['custom_key']) ? bin2hex(random_bytes(6)) : $_POST['custom_key'];
        $days = isset($_POST['expiry_days']) && is_numeric($_POST['expiry_days']) ? $_POST['expiry_days'] : 3;
        $expiresAt = date('Y-m-d H:i:s', strtotime("+$days days"));

        // Check for duplicate key before inserting
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE `key` = ?");
        $stmt->execute([$key]);
        $exists = $stmt->fetchColumn();

        if ($exists) {
            $errorMessage = "Key already exists. Please generate a new one.";
        } else {
            try {
                $stmt = $pdo->prepare("INSERT INTO users (`key`, expires_at) VALUES (?, ?)");
                $stmt->execute([$key, $expiresAt]);
                $successMessage = "Key generated successfully!";
            } catch (Exception $e) {
                $errorMessage = "Failed to generate key.";
            }
        }
    }

    if (isset($_POST['delete_key'])) {
        $deleteKey = $_POST['delete_key'];
        try {
            $stmt = $pdo->prepare("DELETE FROM users WHERE `key` = ?");
            $stmt->execute([$deleteKey]);
            $successMessage = "Key deleted successfully!";
        } catch (Exception $e) {
            $errorMessage = "Failed to delete key.";
        }
    }

    if (isset($_POST['edit_timer'])) {
        $newExpiry = $_POST['new_expiry'];
        $keyToUpdate = $_POST['key_to_update'];

        try {
            $stmt = $pdo->prepare("UPDATE users SET expires_at = ? WHERE `key` = ?");
            $stmt->execute([$newExpiry, $keyToUpdate]);
            $successMessage = "Key expiration updated successfully!";
        } catch (Exception $e) {
            $errorMessage = "Failed to update expiration.";
        }
    }
}

$stmt = $pdo->query("SELECT * FROM users");
$keys = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>TKS Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            background-image: url('dragon-image.jpg');
            background-size: cover;
            background-attachment: fixed;
        }
        .custom-card {
            background-color: rgba(0, 0, 0, 0.6);
            color: #fff;
        }
    </style>
</head>
<body class="bg-gray-900 text-gray-200 p-6 flex items-center justify-center min-h-screen">

<div class="max-w-4xl w-full p-6 custom-card rounded-lg shadow-md mx-auto text-center">
    <h2 class="text-3xl font-bold mb-2">ADMIN PANEL</h2>
    <p class="text-sm text-red-500 mb-6">DEVELOPED BY TKS</p>

    <?php if ($successMessage): ?>
        <div class="bg-green-500 text-white p-3 rounded mb-4"><?= htmlspecialchars($successMessage) ?></div>
    <?php endif; ?>
    <?php if ($errorMessage): ?>
        <div class="bg-red-500 text-white p-3 rounded mb-4"><?= htmlspecialchars($errorMessage) ?></div>
    <?php endif; ?>

    <form method="POST" class="mb-6 bg-gray-800 p-4 rounded-lg text-center">
        <div class="flex flex-col gap-4 mb-4 items-center">
            <div class="flex items-center bg-gray-900 p-2 rounded-md w-full max-w-md mx-auto">
                <i class="fas fa-key text-green-500"></i>
                <input type="text" name="custom_key" class="bg-transparent w-full text-white ml-2 focus:outline-none" placeholder="Enter manual key">
            </div>
            <div class="flex items-center bg-gray-900 p-2 rounded-md w-full max-w-md mx-auto">
                <i class="fas fa-calendar-alt text-red-500"></i>
                <input type="number" name="expiry_days" class="bg-transparent w-full text-white ml-2 focus:outline-none" placeholder="Duration (days)" min="1" max="365">
            </div>
        </div>
        <button type="submit" name="generate_key" class="w-full max-w-xs bg-green-500 hover:bg-green-600 text-white p-2 rounded-md">
            <i class="fas fa-plus"></i> Generate Key
        </button>
    </form>

    <h3 class="text-xl font-semibold mt-6 mb-4">All Keys</h3>
    <div class="space-y-4">
        <?php foreach ($keys as $key): ?>
            <div class="bg-gray-800 p-4 rounded-lg text-center mx-auto max-w-md">
                <p><i class="fas fa-id-badge"></i> ID: <?= htmlspecialchars($key['id']) ?></p>
                <p><i class="fas fa-key"></i> Key: <?= htmlspecialchars($key['key']) ?></p>
                <p><i class="fas fa-clock"></i> Expires: <?= htmlspecialchars($key['expires_at']) ?></p>
                <div class="flex flex-col items-center gap-2 mt-4">
                    <form method="POST" class="w-full">
                        <input type="hidden" name="key_to_update" value="<?= htmlspecialchars($key['key']) ?>">
                        <input type="datetime-local" name="new_expiry" class="bg-gray-700 p-2 text-white rounded-md w-full">
                        <button type="submit" name="edit_timer" class="w-full bg-blue-500 hover:bg-blue-600 text-white p-2 rounded-md mt-2">
                            <i class="fas fa-edit"></i> Update
                        </button>
                    </form>
                    <form method="POST" class="w-full">
                        <input type="hidden" name="delete_key" value="<?= htmlspecialchars($key['key']) ?>">
                        <button type="submit" class="w-full bg-red-500 hover:bg-red-600 text-white p-2 rounded-md">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

</body>
</html>