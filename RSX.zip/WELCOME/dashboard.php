<?php
session_start();
require "config.php";

if (!isset($_SESSION["loggedin"])) {
    header("Location: login.php");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE `key` = ?");
$stmt->execute([$_SESSION["key"]]);
$user = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TKS ULTRA MOD</title>
    <style>
        /* General Styles */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Arial', sans-serif;
            background: url('dragon-image.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #ffffff;
        }
        

        .dashboard {
            text-align: center;
            width: 90%;
            max-width: 300px;
            background: rgba(0, 0, 0, 0.7);
            border-radius: 20px;
            padding: 20px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.8);
        }

        .logo-container {
            width: 70px;
            height: 70px;
            margin: 0 auto 15px auto;
            border: 4px solid #00ff00;
            border-radius: 50%;
            overflow: hidden;
            display: flex;
            justify-content: center;
            align-items: center;
            background: #000000;
        }

        .logo-container img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        h1 {
            font: italic small-caps bold 12px/30px Georgia, serif;
            font-size: 1.5rem;
            margin-bottom: 20px;
            color: #00ff00;
        }

        .info-container {
            margin: 20px 0;
        }

        .info-box {
            display: flex;
            font-size: bold;
            font-family: "Lucida Console", "Courier New", monospace;
            align-items: center;
            justify-content: space-between;
            background: rgba(0, 0, 0, 0.5);
            border: 2px solid #00ff00;
            border-radius: 10px;
            padding: 10px;
            margin-bottom: 15px;
        }

        .info-box i {
            font-size: 1.5rem;
            color: #00ff00;
        }

        .info-box span {
            font-size: 0.9rem;
            flex-grow: 1;
            margin-left: 10px;
            color: #ffffff;
            text-align: left;
        }

        .status {
            font-family: "Lucida Console", "Courier New", monospace;
            font-size: 1.5rem;
            color: #00ff00;
            margin: 20px 0;
        }

        .open-game-btn {
            font: italic small-caps bold 12px/30px Georgia, serif;
            display: inline-block;
            background: #00ff00;
            color: #000000;
            padding: 10px 20px;
            font-size: 1rem;
            border-radius: 10px;
            text-decoration: none;
            text-transform: uppercase;
            font-weight: bold;
            transition: background 0.3s ease;
        }

        .open-game-btn:hover {
            background: #00cc00;
        }

        @media (max-width: 768px) {
            .dashboard {
                width: 95%;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <div class="logo-container">
            <img src="TKS.png" alt="Dragon Logo">
        </div>
        <h1>TKS ULTRA MOD 2.0</h1>

        <div class="info-container">
            <div class="info-box">
                <i class="fas fa-key"></i>
                <span>KEY: <?= htmlspecialchars($user['key']) ?></span>
            </div>
            <div class="info-box">
                <i class="fas fa-mobile-alt"></i>
                <span>DEVICE: <?= htmlspecialchars($user['device_id']) ?></span>
            </div>
            <div class="info-box">
                <i class="fas fa-clock"></i>
                <span>EXPIRED: <?= htmlspecialchars($user['expires_at']) ?></span>
            </div>
        </div>

        <div class="status">SERVER IS CONNECTED</div>
        <a href="content.php" class="open-game-btn">Open Game</a>
    </div>
</body>
</html>