<?php
session_start();
require "config.php";
require "device.php";

$errorMessage = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $key = $_POST["key"]; 
    $deviceID = getDeviceID();

    try {
       
        $query = "SELECT * FROM users WHERE `key` = '$key' AND expires_at > NOW()";
        $result = $pdo->query($query); 
        $user = $result->fetch();

        if ($user) {
            if ($user['device_id'] === NULL) {
               
                $updateQuery = "UPDATE users SET device_id = '$deviceID' WHERE `key` = '$key'";
                $pdo->query($updateQuery);
                $_SESSION["loggedin"] = true;
                $_SESSION["key"] = $key;
                header("Location: dashboard.php");
                exit;
            } elseif ($user['device_id'] === $deviceID) {
                $_SESSION["loggedin"] = true;
                $_SESSION["key"] = $key;
                header("Location: dashboard.php");
                exit;
            } else {
                $errorMessage = "Access denied: Key is already used on another device.";
            }
        } else {
            $errorMessage = "Invalid or expired key!";
        }
    } catch (PDOException $e) {
       
        $errorMessage = "Database error: " . $e->getMessage();
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TKS ULTRA MOD</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Roboto', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: url('dragon-image.jpg') no-repeat center center/cover;
        }

        .login-container {
            width: 90%;
            max-width: 400px;
            background: rgba(0, 0, 0, 0.6);
            border-radius: 15px;
            backdrop-filter: blur(10px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.7);
            text-align: center;
            padding: 30px 20px;
            color: #ffffff;
        }

        .login-icon {
            font-size: 60px;
            color: #00ff99;
            margin-bottom: 20px;
        }

        .login-container h1 {
            font: italic small-caps bold 12px/30px Georgia, serif;
            font-size: 26px;
            margin-bottom: 20px;
        }

        .login-input {
            font-family: "Lucida Console", "Courier New", monospace;
            width: 70%;
            padding: 10px 15px;
            margin-bottom: 20px;
            border: none;
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.2);
            color: #ffffff;
            font-size: 16px;
            outline: none;
        }

        .login-input::placeholder {
            color: #bfbfbf;
        }

        .login-button {
            font: italic small-caps bold 12px/30px Georgia, serif;
            width: 50%;
            padding: 12px;
            margin-top: 10px;
            border: none;
            border-radius: 8px;
            background: linear-gradient(135deg, #00ff99, #007a5f);
            color: #ffffff;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .login-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 255, 153, 0.4);
        }

        .copy-device-id {
            font: italic small-caps bold 12px/30px Georgia, serif;
            margin-top: 15px;
            font-size: 14px;
            cursor: pointer;
            text-decoration: none;
            color: #00ff99;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .copy-device-id i {
            margin-right: 5px;
        }

        .copy-device-id:hover {
            text-decoration: underline;
        }

        .error-popup, .copy-popup {
            background: rgba(255, 69, 58, 0.9);
            color: white;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 8px;
            text-align: center;
            animation: fade-in 0.5s ease;
            display: none;
        }

        .copy-popup {
            background: rgba(0, 255, 153, 0.9);
        }

        @keyframes fade-in {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        @media (max-width: 768px) {
            .login-container {
                padding: 20px 15px;
            }

            .login-button {
                font-size: 16px;
                padding: 10px;
            }

            .login-container h1 {
                font-size: 22px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-icon">
            <i class="fas fa-user-circle"></i>
        </div>
        
        <h1>Tks Ultra Mod 2.0</h1>
        <?php if (!empty($errorMessage)) : ?>
            <div class="error-popup" id="error-popup"><?php echo $errorMessage; ?></div>
        <?php endif; ?>
        <form method="POST">
            <input type="text" class="login-input" name="key" placeholder="Enter your key" required>
            <button type="submit" class="login-button"><i class="fas fa-sign-in-alt"></i> Login</button>
        </form>
        <div class="copy-device-id" onclick="copyDeviceId()">
            <i class="fas fa-copy"></i> Copy Device ID
        </div>
        <div class="copy-popup" id="copyPopup">Device ID copied to clipboard!</div>
    </div>

    <script>
        function generateDeviceId() {
            const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
            let deviceId = '';
            for (let i = 0; i < 9; i++) {
                const randomIndex = Math.floor(Math.random() * characters.length);
                deviceId += characters[randomIndex];
            }
            return deviceId;
        }

        let deviceId = localStorage.getItem('device_id');
        if (!deviceId) {
            deviceId = generateDeviceId();
            localStorage.setItem('device_id', deviceId);
        }

        function copyDeviceId() {
            navigator.clipboard.writeText(deviceId).then(() => {
                const copyPopup = document.getElementById('copyPopup');
                copyPopup.style.display = 'block';
                setTimeout(() => {
                    copyPopup.style.display = 'none';
                }, 2000);
            });
        }
    </script>
</body>
</html>